import javafx.geometry.Pos;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Set;

public class CalendarView {

    private static final int CIRCLE_RADIUS = 30;

    public StackPane getView(Set<Integer> loggedInDays) {
        StackPane root = new StackPane();
        VBox content = new VBox(15); // 15px space between row and label
        content.setAlignment(Pos.CENTER);

        HBox circleRow = new HBox(15);
        circleRow.setAlignment(Pos.CENTER);

        DayOfWeek currentDay = LocalDate.now().getDayOfWeek();
        int currentDayIndex = currentDay.getValue(); // Monday = 1

        String[] dayNames = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};

        for (int i = 1; i <= 7; i++) {
            Circle mainCircle = new Circle(CIRCLE_RADIUS);
            Text label = new Text(dayNames[i - 1]);

            if (i == currentDayIndex) {
                mainCircle.setFill(Color.RED);
            } else {
                mainCircle.setFill(Color.GREEN);
            }

            StackPane circleWithRing = new StackPane();

            if (loggedInDays.contains(i)) {
                Circle goldenRing = new Circle(CIRCLE_RADIUS + 5);
                goldenRing.setFill(Color.TRANSPARENT);
                goldenRing.setStroke(Color.GOLD);
                goldenRing.setStrokeWidth(3);
                circleWithRing.getChildren().add(goldenRing);
            }

            circleWithRing.getChildren().add(mainCircle);

            VBox dayBox = new VBox(5, circleWithRing, label);
            dayBox.setAlignment(Pos.CENTER);
            circleRow.getChildren().add(dayBox);
        }

        // Add login count label
        Text loginCount = new Text("Total login days: " + loggedInDays.size());
        Text mark = new Text("This is only a prototype.");

        content.getChildren().addAll(circleRow, loginCount, mark);
        root.getChildren().add(content);

        return root;
    }
}
