import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.*;

public class LoginPage {

    private TextField tfUserName;
    private PasswordField tfPassword;
    private Button btnLogin, btnEnroll, btnClearFile;

    private String fileName = "UserNames.txt";

    public void createLoginPage(Stage stage) {
        fileCheck(fileName);

        VBox layout = new VBox(10);

        tfUserName = new TextField();
        tfUserName.setPromptText("Username");

        tfPassword = new PasswordField();
        tfPassword.setPromptText("Password");

        btnEnroll = new Button("Enroll");
        btnLogin = new Button("Login");
        btnClearFile = new Button("Clear File");

        btnLogin.setOnAction(e -> handleLogin(stage));
        btnEnroll.setOnAction(e -> handleEnroll());
        btnClearFile.setOnAction(e -> handleClearFile());

        layout.getChildren().addAll(tfUserName, tfPassword, btnLogin, btnEnroll, btnClearFile);

        Scene scene = new Scene(layout, 400, 300);
        stage.setTitle("Login Page");
        stage.setScene(scene);
        stage.show();
    }

    private void fileCheck(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("Save file not found. New file created.");
                }
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } else {
            System.out.println("Save file found.");
        }
    }

    private void handleLogin(Stage stage) {
        String inputU = tfUserName.getText().trim();
        String inputP = tfPassword.getText().trim();

        if (inputU.isEmpty() || inputP.isEmpty()) {
            showError("Username and Password cannot be empty");
            return;
        }

        boolean userFound = false;
        boolean loginSuccessful = false;
        String storedP = null;
        int loginCount = 0;
        List<Integer> loginDays = new ArrayList<>();
        int recordedWeek = -1;
        List<String> allLines = new ArrayList<>();
        String matchedLine = null;

        try (Scanner sc = new Scanner(new File(fileName))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                allLines.add(line);
                String[] parts = line.split("XXXX");

                if (parts.length >= 4) {
                    String storedU = parts[0];
                    if (storedU.equals(inputU)) {
                        userFound = true;
                        storedP = parts[1];
                        loginCount = Integer.parseInt(parts[2]);
                        String loginDaysRaw = parts[3];

                        // Parse login days
                        String[] loginDayParts = loginDaysRaw.split("XX");
                        String recordedDaysStr = loginDayParts.length > 0 ? loginDayParts[0] : "";
                        String[] recordedDaysArray = recordedDaysStr.isEmpty() ? new String[0] : recordedDaysStr.split("X");

                        for (String d : recordedDaysArray) {
                            try {
                                loginDays.add(Integer.parseInt(d));
                            } catch (NumberFormatException ignored) {}
                        }

                        if (parts.length >= 5) {
                            try {
                                recordedWeek = Integer.parseInt(parts[4]);
                            } catch (NumberFormatException ignored) {}
                        }

                        matchedLine = line;
                        break;
                    }
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            showError("Error reading user data file");
            return;
        }

        if (!userFound) {
            showError("Username not found");
            return;
        }

        if (!inputP.equals(storedP)) {
            showError("Incorrect password");
            return;
        }

        // Password is correct: update login data
        LocalDate today = LocalDate.now();
        int currentDayOfWeek = today.getDayOfWeek().getValue(); // 1 = Monday
        int currentWeek = today.get(WeekFields.ISO.weekOfWeekBasedYear());

        if (recordedWeek != currentWeek) {
            loginDays.clear();
            loginCount++;
        } else if (!loginDays.contains(currentDayOfWeek)) {
            loginDays.add(currentDayOfWeek);
            loginCount++;
        }

        Collections.sort(loginDays);
        StringBuilder sb = new StringBuilder();
        for (int day : loginDays) {
            sb.append(day).append("X");
        }
        sb.append("X"); // Ending "XX"

        String updatedLine = inputU + "XXXX" + storedP + "XXXX" + loginCount + "XXXX" + sb + "XXXX" + currentWeek + "\n";

        // Rebuild file with updated line
        List<String> updatedLines = new ArrayList<>();
        for (String line : allLines) {
            if (line.equals(matchedLine)) {
                updatedLines.add(updatedLine);
            } else {
                updatedLines.add(line);
            }
        }

        try (FileWriter writer = new FileWriter(fileName, false)) {
            for (String updated : updatedLines) {
                writer.write(updated + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
            showError("Failed to update login information.");
            return;
        }

        // Pass the logged-in days to the main application
        Integer[] loginDaysArray = loginDays.toArray(new Integer[0]);
        loginSuccess(inputU, stage, loginDaysArray);
    }

    private void loginSuccess(String name, Stage stage, Integer[] loginDaysArray) {
        Project_Accounting app = new Project_Accounting();
        app.startMainApplication(stage, name, loginDaysArray);
    }


    private void showError(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void handleEnroll() {
        String inputU = tfUserName.getText().trim();
        String inputP = tfPassword.getText().trim();

        if (inputU.isEmpty() || inputP.isEmpty()) {
            showError("Username and Password cannot be empty");
            return;
        }

        // Check for duplicate user names
        try (Scanner sc = new Scanner(new File(fileName))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] parts = line.split("XXXX");
                if (parts.length >= 1 && parts[0].equals(inputU)) {
                    showError("Username already exists!");
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            showError("Error checking existing users");
            return;
        }

        LocalDate today = LocalDate.now();
        int currentDay = today.getDayOfWeek().getValue(); // 1 = Monday
        int currentWeek = today.get(WeekFields.ISO.weekOfWeekBasedYear());

        String loginDays = currentDay + "X" + "X"; 

        try (FileWriter writer = new FileWriter(fileName, true)) {  // true = append
            writer.write(inputU + "XXXX" + inputP + "XXXX1XXXX" + loginDays + "XXXX" + currentWeek + "\n");
            showSuccess("Enrollment successful!");
        } catch (IOException e) {
            e.printStackTrace();
            showError("Error enrolling user");
        }
    }
    
    public int[] getWeekLogin(String username) {
        try (Scanner sc = new Scanner(new File(fileName))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] parts = line.split("XXXX");

                if (parts.length >= 4 && parts[0].equals(username)) {
                    String loginDaysRaw = parts[3]; // example: 0X1X2X3X X

                    // Remove the trailing "XX" and split by "X"
                    String[] dayParts = loginDaysRaw.split("XX")[0].split("X");

                    List<Integer> dayList = new ArrayList<>();
                    for (String part : dayParts) {
                        if (!part.isEmpty()) {
                            try {
                                int day = Integer.parseInt(part);
                                if (!dayList.contains(day)) {
                                    dayList.add(day);
                                }
                            } catch (NumberFormatException ignored) {}
                        }
                    }

                    // Convert list to array
                    int[] result = new int[dayList.size()];
                    for (int i = 0; i < dayList.size(); i++) {
                        result[i] = dayList.get(i);
                    }
                    return result;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // If not found or error, return empty array
        return new int[0];
    }

    private void handleClearFile() {
        File file = new File(fileName);
        if (file.exists() && file.delete()) {
            showSuccess("User data file cleared");
        } else {
            showError("Error clearing user data file");
        }
    }
}
