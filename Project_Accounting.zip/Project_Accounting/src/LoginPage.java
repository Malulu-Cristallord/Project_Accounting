import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.*;

public class LoginPage {

    private TextField tfUserName;
    private PasswordField tfPassword;
    private Button btnLogin, btnEnroll, btnClearFile;

    private String fileName = "UserNames.txt";

    public void createLoginPage(Stage stage) {
        fileCheck(fileName);

        VBox layout = new VBox(10);

        tfUserName = new TextField();
        tfUserName.setPromptText("Username");

        tfPassword = new PasswordField();
        tfPassword.setPromptText("Password");

        btnEnroll = new Button("Enroll");
        btnLogin = new Button("Login");
        btnClearFile = new Button("Clear File");

        btnLogin.setOnAction(e -> handleLogin(stage));
        btnEnroll.setOnAction(e -> handleEnroll());
        btnClearFile.setOnAction(e -> handleClearFile());

        layout.getChildren().addAll(tfUserName, tfPassword, btnLogin, btnEnroll, btnClearFile);

        Scene scene = new Scene(layout, 400, 300);
        stage.setTitle("Login Page");
        stage.setScene(scene);
        stage.show();
    }

    private void fileCheck(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            try {
                if (file.createNewFile()) {
                    System.out.println("Save file not found. New file created.");
                }
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } else {
            System.out.println("Save file found.");
        }
    }

    private void handleLogin(Stage stage) {
        String inputU = tfUserName.getText().trim();
        String inputP = tfPassword.getText().trim();

        if (inputU.isEmpty() || inputP.isEmpty()) {
            showError("Username and Password cannot be empty");
            return;
        }

        List<String> updatedLines = new ArrayList<>();
        boolean userFound = false;
        boolean loginSuccessful = false;

        LocalDate today = LocalDate.now();
        int currentDayOfWeek = today.getDayOfWeek().getValue(); // 1 = Monday, 7 = Sunday
        int currentWeek = today.get(WeekFields.ISO.weekOfWeekBasedYear());

        try (Scanner sc = new Scanner(new File(fileName))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String[] parts = line.split("XXXX");

                if (parts.length >= 4) {
                    String storedU = parts[0];
                    String storedP = parts[1];
                    int loginCount = Integer.parseInt(parts[2]);
                    String loginDaysRaw = parts[3];

                    if (storedU.equals(inputU)) {
                        userFound = true;
                        if (storedP.equals(inputP)) {
                            // Extract week and days
                            String[] loginDayParts = loginDaysRaw.split("XX");
                            String recordedDaysStr = loginDayParts.length > 0 ? loginDayParts[0] : "";
                            String[] recordedDaysArray = recordedDaysStr.isEmpty() ? new String[0] : recordedDaysStr.split("X");

                            List<Integer> loginDays = new ArrayList<>();
                            for (String d : recordedDaysArray) {
                                try {
                                    loginDays.add(Integer.parseInt(d));
                                } catch (NumberFormatException ignored) {}
                            }

                            // Get previously recorded week
                            int recordedWeek = -1;
                            if (parts.length >= 5) {
                                try {
                                    recordedWeek = Integer.parseInt(parts[4]);
                                } catch (NumberFormatException ignored) {}
                            }

                            // If new week, reset days
                            if (recordedWeek != currentWeek) {
                                loginDays.clear();
                                loginCount++;
                            } else if (!loginDays.contains(currentDayOfWeek)) {
                                loginDays.add(currentDayOfWeek);
                                loginCount++;
                            }

                            // Sort and build updated loginDays string
                            Collections.sort(loginDays);
                            StringBuilder sb = new StringBuilder();
                            for (int day : loginDays) {
                                sb.append(day - 1).append("X");
                            }
                            sb.append("X"); // Ending XX

                            updatedLines.add(storedU + "XXXX" + storedP + "XXXX" + loginCount + "XXXX" + sb + "XXXX" + currentWeek + ";\n");
                            loginSuccessful = true;
                            continue;
                        } else {
                            showError("Incorrect password");
                            return;
                        }
                    }
                }

                updatedLines.add(line); // unchanged line
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            showError("Error reading user data file");
            return;
        }

        if (!userFound) {
            showError("Username not found");
            return;
        }

        // Save updates
        if (loginSuccessful) {
            try (FileWriter writer = new FileWriter(fileName, false)) {
                for (String updatedLine : updatedLines) {
                    writer.write(updatedLine + "\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
                showError("Failed to update login information.");
                return;
            }

            loginSuccess(inputU, stage);
            /*
             * Remember to deliver the logindays data to the main page!
             */
        }
    }

    private void loginSuccess(String name, Stage stage) {
        Project_Accounting app = new Project_Accounting();
        app.startMainApplication(stage);
    }

    private void showError(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void handleEnroll() {
        String inputU = tfUserName.getText().trim();
        String inputP = tfPassword.getText().trim();

        if (inputU.isEmpty() || inputP.isEmpty()) {
            showError("Username and Password cannot be empty");
            return;
        }

        LocalDate today = LocalDate.now();
        int currentDay = today.getDayOfWeek().getValue(); // 1 = Monday
        int currentWeek = today.get(WeekFields.ISO.weekOfWeekBasedYear());

        String loginDays = currentDay + "X" + "X"; // e.g., 1X X (meaning Monday)

        try (FileWriter writer = new FileWriter(fileName, false)) {
            writer.write(inputU + "XXXX" + inputP + "XXXX1XXXX" + loginDays + "XXXX" + currentWeek + "\n");
            showSuccess("Enrollment successful!");
        } catch (IOException e) {
            e.printStackTrace();
            showError("Error enrolling user");
        }
    }

    private void handleClearFile() {
        File file = new File(fileName);
        if (file.exists() && file.delete()) {
            showSuccess("User data file cleared");
        } else {
            showError("Error clearing user data file");
        }
    }
}
